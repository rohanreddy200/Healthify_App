package com.mypackage.it314_health_center.videocalling.AroraFiles;

/** Created by Li on 10/1/2016. */
public interface Packable {
  ByteBuf marshal(ByteBuf out);
}
