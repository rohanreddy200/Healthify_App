package com.mypackage.it314_health_center.videocalling.AroraFiles;

public interface PackableEx extends Packable {
  void unmarshal(ByteBuf in);
}
