package com.mypackage.it314_health_center

class basicDoctor {

    var name: String? = null
    var email: String? = null

    constructor() {}

    constructor(name: String?, email: String?) {
        this.name = name
        this.email = email
    }
}