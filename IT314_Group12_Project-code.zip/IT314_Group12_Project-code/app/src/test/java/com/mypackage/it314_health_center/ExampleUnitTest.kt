package com.mypackage.it314_health_center

import org.junit.Assert.assertEquals
import org.junit.Test


class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
}